CHEP PANDA — SITIO LISTO PARA NETLIFY

1. Descomprime este ZIP.
2. En Netlify Drop, sube la carpeta chep-panda-web (no el ZIP).
3. index.html debe quedar directamente dentro de la carpeta subida.
4. El sitio usa solo HTML/CSS/JS y funciona sin servidor.

Pedido por WhatsApp: +58 414-6688828
Dirección: Av. Urdaneta, al lado del Ministerio Público
Horario: 11:00 AM - 10:00 PM
Instagram: @cheppanda2025
